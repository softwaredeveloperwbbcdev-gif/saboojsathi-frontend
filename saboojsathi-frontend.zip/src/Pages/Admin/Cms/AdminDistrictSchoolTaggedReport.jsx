import React from "react";

const AdminDistrictSchoolTaggedReport = () => {
  return <div>AdminDistrictSchoolTaggedReport</div>;
};

export default AdminDistrictSchoolTaggedReport;
