import React from "react";

const AdminTaggingUnloadReport = () => {
  return <div>AdminTaggingUnloadReport</div>;
};

export default AdminTaggingUnloadReport;
